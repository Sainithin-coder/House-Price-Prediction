"""
Synthetic House Price Dataset Generator
Generates realistic heterogeneous housing data with structured + categorical + textual features.
"""
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import os

np.random.seed(42)

def generate_dataset(n_samples=3000):
    cities = ['Maharashtra', 'Karnataka', 'Tamil Nadu', 'Delhi', 'Telangana',
              'Gujarat', 'Rajasthan', 'West Bengal', 'Uttar Pradesh', 'Kerala']
    neighborhoods = ['Banjara Hills', 'Koramangala', 'Juhu', 'Connaught Place', 'Anna Nagar',
                     'Salt Lake', 'Gomti Nagar', 'Baner', 'Whitefield', 'Marine Drive']
    property_types = ['Independent House', 'Apartment', 'Villa', 'Builder Floor', 'Penthouse']
    conditions = ['Excellent', 'Good', 'Fair', 'Poor']
    garage_types = ['Covered Parking', 'Open Parking', 'None', 'Basement Parking']
    school_ratings = ['A+', 'A', 'B+', 'B', 'C+', 'C']

    city_base = {
        'Maharashtra': 9500000, 'Karnataka': 7200000, 'Tamil Nadu': 6800000,
        'Delhi': 12000000, 'Telangana': 7500000, 'Gujarat': 5500000,
        'Rajasthan': 4200000, 'West Bengal': 5800000, 'Uttar Pradesh': 4500000, 'Kerala': 6000000
    }
    condition_mult = {'Excellent': 1.20, 'Good': 1.05, 'Fair': 0.90, 'Poor': 0.75}
    school_mult = {'A+': 1.15, 'A': 1.10, 'B+': 1.05, 'B': 1.00, 'C+': 0.95, 'C': 0.90}

    data = {}
    city_arr = np.random.choice(cities, n_samples)
    neighborhood_arr = np.random.choice(neighborhoods, n_samples)
    property_type_arr = np.random.choice(property_types, n_samples)
    condition_arr = np.random.choice(conditions, n_samples, p=[0.25, 0.45, 0.20, 0.10])
    garage_arr = np.random.choice(garage_types, n_samples, p=[0.45, 0.20, 0.25, 0.10])
    school_arr = np.random.choice(school_ratings, n_samples, p=[0.10, 0.20, 0.20, 0.25, 0.15, 0.10])

    sqft = np.random.normal(1400, 600, n_samples).clip(400, 5000).astype(int)
    bedrooms = np.random.choice([1, 2, 3, 4, 5, 6], n_samples, p=[0.08, 0.20, 0.38, 0.24, 0.07, 0.03])
    bathrooms = np.clip(bedrooms * np.random.uniform(0.5, 1.0, n_samples), 1, 5).astype(int)
    year_built = np.random.randint(1970, 2024, n_samples)
    lot_size = np.random.normal(2000, 800, n_samples).clip(500, 10000).astype(int)   # sq.ft. (Indian plots)
    floors = np.random.choice([1, 2, 3, 4, 5], n_samples, p=[0.20, 0.30, 0.25, 0.15, 0.10])
    has_pool = np.random.choice([0, 1], n_samples, p=[0.80, 0.20])
    has_basement = np.random.choice([0, 1], n_samples, p=[0.65, 0.35])
    distance_cbd = np.random.uniform(0.5, 40, n_samples).round(1)   # km
    crime_rate = np.random.uniform(1, 10, n_samples).round(2)
    walk_score = np.random.randint(20, 100, n_samples)
    renovation_year = np.where(
        np.random.random(n_samples) > 0.4,
        np.random.randint(2000, 2024, n_samples),
        year_built
    )

    prices = []
    for i in range(n_samples):
        base = city_base[city_arr[i]]          # base in INR
        price = base
        price += sqft[i] * np.random.uniform(3000, 8000)       # INR per sqft
        price += bedrooms[i] * np.random.uniform(200000, 500000)
        price += bathrooms[i] * np.random.uniform(100000, 300000)
        price *= condition_mult[condition_arr[i]]
        price *= school_mult[school_arr[i]]
        if has_pool[i]: price += np.random.uniform(500000, 2000000)
        if has_basement[i]: price += np.random.uniform(300000, 800000)
        price -= distance_cbd[i] * np.random.uniform(50000, 200000)
        price -= crime_rate[i] * np.random.uniform(100000, 300000)
        price += walk_score[i] * np.random.uniform(5000, 20000)
        price += (2024 - year_built[i]) * np.random.uniform(-10000, -3000)
        if garage_arr[i] != 'None': price += np.random.uniform(200000, 600000)
        price *= np.random.uniform(0.92, 1.08)
        prices.append(max(1000000, price))     # min 10 Lakh INR

    data = {
        'city': city_arr,
        'neighborhood': neighborhood_arr,
        'property_type': property_type_arr,
        'condition': condition_arr,
        'garage_type': garage_arr,
        'school_rating': school_arr,
        'sqft': sqft,
        'bedrooms': bedrooms,
        'bathrooms': bathrooms,
        'year_built': year_built,
        'lot_size': lot_size,
        'floors': floors,
        'has_pool': has_pool,
        'has_basement': has_basement,
        'distance_cbd': distance_cbd,
        'crime_rate': crime_rate,
        'walk_score': walk_score,
        'renovation_year': renovation_year,
        'price': np.array(prices).astype(int)
    }

    df = pd.DataFrame(data)
    os.makedirs('data', exist_ok=True)
    df.to_csv('data/house_data.csv', index=False)
    print(f"[DataGenerator] Dataset created: {n_samples} samples -> data/house_data.csv")
    return df


if __name__ == '__main__':
    df = generate_dataset()
    print(df.describe())
