/* ═══════════════════════════════════════════════════════════════
   HousePriceAI — Frontend Logic
   Handles: prediction, dashboard charts, training history display
   ═══════════════════════════════════════════════════════════════ */

'use strict';

// ─── Chart instances ───────────────────────────────────────────────────────
const charts = {};
let currentAttnData = { num: [], cat: [] };
let currentTab = 'num';

// ─── Chart defaults ────────────────────────────────────────────────────────
Chart.defaults.color = '#94a3b8';
Chart.defaults.font.family = "'Segoe UI', system-ui, sans-serif";

function chartDefaults(label, color) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: { backgroundColor: '#1e293b', borderColor: '#334155', borderWidth: 1 }
    },
    scales: {
      x: { grid: { color: 'rgba(51,65,85,0.5)' }, ticks: { font: { size: 11 } } },
      y: { grid: { color: 'rgba(51,65,85,0.5)' }, ticks: { font: { size: 11 } } }
    }
  };
}

// ─── Health check ─────────────────────────────────────────────────────────
async function checkHealth() {
  try {
    const r = await fetch('/health');
    const d = await r.json();
    const dot  = document.getElementById('statusDot');
    const text = document.getElementById('statusText');
    if (d.status === 'ok') {
      dot.className = 'status-dot online';
      text.textContent = d.model_loaded ? 'Model Ready' : 'No Model — Train First';
    }
  } catch {
    document.getElementById('statusDot').className = 'status-dot offline';
    document.getElementById('statusText').textContent = 'Server Offline';
  }
}

// ─── Slider display ────────────────────────────────────────────────────────
function updateSlider(el, targetId) {
  const v = parseFloat(el.value);
  const fmt = el.name === 'walk_score' ? v : v.toFixed(1);
  const suffix = el.name === 'distance_cbd' ? ' km' : '';
  document.getElementById(targetId).textContent = fmt + suffix;
}

// ─── Format currency (Indian Rupees) ──────────────────────────────────────
function fmt$(n) {
  if (n >= 10_000_000) return '₹' + (n / 10_000_000).toFixed(2) + ' Cr';
  if (n >= 100_000)    return '₹' + (n / 100_000).toFixed(2) + ' L';
  if (n >= 1_000)      return '₹' + (n / 1_000).toFixed(0) + 'K';
  return '₹' + n;
}
function fmtFull$(n) {
  // Indian number format: ₹1,23,45,678
  return '₹' + Number(n).toLocaleString('en-IN');
}

// ─── Tab switcher ──────────────────────────────────────────────────────────
function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-btn')[tab === 'num' ? 0 : 1].classList.add('active');
  renderAttnChart(tab);
}

function renderAttnChart(tab) {
  const data = tab === 'num' ? currentAttnData.num : currentAttnData.cat;
  const labels = data.map(d => d.feature);
  const values = data.map(d => d.score);
  const color  = tab === 'num' ? '#38bdf8' : '#a78bfa';

  if (charts.attn) charts.attn.destroy();
  const ctx = document.getElementById('attnChart').getContext('2d');
  charts.attn = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{ data: values, backgroundColor: color + '99', borderColor: color, borderWidth: 2, borderRadius: 6 }]
    },
    options: {
      ...chartDefaults(),
      indexAxis: 'y',
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(51,65,85,0.5)' }, min: 0 },
        y: { grid: { display: false }, ticks: { font: { size: 11 } } }
      }
    }
  });
}

// ─── Prediction ────────────────────────────────────────────────────────────
document.getElementById('predictionForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('predictBtn');
  const spinner = document.getElementById('btnSpinner');
  btn.disabled = true;
  spinner.style.display = 'inline-block';
  document.getElementById('btnSpinner').parentElement.querySelector('.btn-text').textContent = 'Predicting...';

  const fd = new FormData(e.target);
  const payload = {};
  for (const [k, v] of fd.entries()) payload[k] = v;

  // Handle checkboxes (unchecked = 0)
  payload.has_pool     = document.getElementById('has_pool').checked     ? 1 : 0;
  payload.has_basement = document.getElementById('has_basement').checked ? 1 : 0;

  try {
    const resp = await fetch('/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await resp.json();

    if (data.error) {
      showError(data.error);
    } else {
      showResult(data);
    }
  } catch (err) {
    showError('Network error: ' + err.message);
  } finally {
    btn.disabled = false;
    spinner.style.display = 'none';
    document.getElementById('btnSpinner').parentElement.querySelector('.btn-text').textContent = 'Predict House Price';
  }
});

function showResult(data) {
  document.getElementById('resultPlaceholder').style.display = 'none';
  document.getElementById('resultError').style.display = 'none';
  const content = document.getElementById('resultContent');
  content.style.display = 'block';

  // Price
  const priceEl = document.getElementById('priceMain');
  priceEl.textContent = fmtFull$(data.predicted_price);
  priceEl.classList.remove('price-pop');
  void priceEl.offsetWidth;
  priceEl.classList.add('price-pop');

  document.getElementById('priceRange').textContent =
    `Range: ${fmtFull$(data.price_low)} — ${fmtFull$(data.price_high)}`;
  document.getElementById('pricePsf').textContent =
    `\u20B9${data.price_per_sqft} per sq.ft.`;

  // Confidence (inverse of relative range width, heuristic)
  const rangeWidth = (data.price_high - data.price_low) / data.predicted_price;
  const conf = Math.round(Math.max(60, Math.min(95, (1 - rangeWidth) * 100)));
  document.getElementById('confBar').style.width = conf + '%';
  document.querySelector('.conf-pct').textContent = conf + '%';

  // Model badge
  const mi = data.model_info;
  document.getElementById('maeBadge').textContent =
    mi.final_val_mae ? `MAE: ${fmt$(mi.final_val_mae)}` : '';

  // Attention data
  currentAttnData.num = data.num_importance || [];
  currentAttnData.cat = data.cat_importance || [];
  renderAttnChart(currentTab);

  checkHealth();
}

function showError(msg) {
  document.getElementById('resultPlaceholder').style.display = 'none';
  document.getElementById('resultContent').style.display = 'none';
  const err = document.getElementById('resultError');
  err.style.display = 'block';
  document.getElementById('errorMsg').textContent = msg;
  checkHealth();
}

// ─── Dashboard ─────────────────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const r = await fetch('/stats');
    const d = await r.json();
    if (d.error) return alert('Stats error: ' + d.error);

    // Stats cards
    document.getElementById('statTotal').textContent = Number(d.total_records).toLocaleString();
    document.getElementById('statAvg').textContent   = fmt$(d.avg_price);
    document.getElementById('statMin').textContent   = fmt$(d.min_price);
    document.getElementById('statMax').textContent   = fmt$(d.max_price);
    // city avg in Lakhs
    document.getElementById('statsGrid').style.display = 'grid';
    document.getElementById('chartsGrid').style.display = 'grid';

    // Price distribution
    buildBar('distChart', d.price_distribution.bins, d.price_distribution.counts,
      'House Count', '#4f46e5', '#818cf8');

    // City avg
    const cities = Object.keys(d.city_avg_price);
    const cityPrices = Object.values(d.city_avg_price).map(v => Math.round(v / 100000));
    buildHBar('cityChart', cities, cityPrices, 'Avg Price (Lakhs)', '#0ea5e9', '₹', 'L');

    // Property type
    const types  = Object.keys(d.property_type_avg);
    const tPrices = Object.values(d.property_type_avg).map(v => Math.round(v / 100000));
    buildDoughnut('typeChart', types, tPrices);

    // Correlations
    const corrKeys = Object.keys(d.feature_correlations);
    const corrVals = Object.values(d.feature_correlations);
    buildCorrChart('corrChart', corrKeys, corrVals);

  } catch (e) {
    alert('Failed to load stats: ' + e.message);
  }
}

function buildBar(id, labels, data, label, bgColor, borderColor) {
  if (charts[id]) charts[id].destroy();
  const ctx = document.getElementById(id).getContext('2d');
  charts[id] = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label, data,
        backgroundColor: bgColor + '80',
        borderColor: borderColor || bgColor,
        borderWidth: 2, borderRadius: 4
      }]
    },
    options: {
      ...chartDefaults(),
      plugins: { legend: { display: false } }
    }
  });
}

function buildHBar(id, labels, data, label, color, prefix='₹', suffix='L') {
  if (charts[id]) charts[id].destroy();
  const ctx = document.getElementById(id).getContext('2d');
  charts[id] = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{ label, data, backgroundColor: color + '80', borderColor: color, borderWidth: 2, borderRadius: 4 }]
    },
    options: {
      ...chartDefaults(),
      indexAxis: 'y',
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(51,65,85,0.5)' }, ticks: { callback: v => prefix + v + ' ' + suffix } },
        y: { grid: { display: false } }
      }
    }
  });
}

function buildDoughnut(id, labels, data) {
  if (charts[id]) charts[id].destroy();
  const ctx = document.getElementById(id).getContext('2d');
  const colors = ['#4f46e5','#0ea5e9','#10b981','#f59e0b','#ef4444'];
  charts[id] = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{ data, backgroundColor: colors.map(c => c + 'cc'), borderColor: colors, borderWidth: 2 }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 12 } },
        tooltip: { backgroundColor: '#1e293b', borderColor: '#334155', borderWidth: 1,
          callbacks: { label: (c) => ` \u20B9${c.parsed} L` } }
      }
    }
  });
}

function buildCorrChart(id, labels, data) {
  if (charts[id]) charts[id].destroy();
  const ctx = document.getElementById(id).getContext('2d');
  const colors = data.map(v => v >= 0 ? '#10b981cc' : '#ef4444cc');
  const borders = data.map(v => v >= 0 ? '#10b981' : '#ef4444');
  charts[id] = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{ label: 'Correlation', data, backgroundColor: colors, borderColor: borders, borderWidth: 2, borderRadius: 4 }]
    },
    options: {
      ...chartDefaults(),
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(51,65,85,0.5)' }, ticks: { maxRotation: 45, font: { size: 10 } } },
        y: { grid: { color: 'rgba(51,65,85,0.5)' }, min: -1, max: 1, ticks: { stepSize: 0.25 } }
      }
    }
  });
}

// ─── Training History ──────────────────────────────────────────────────────
async function loadHistory() {
  try {
    const r = await fetch('/history');
    if (!r.ok) {
      showTrainingStatus('No training history found. Train the model first.', 'error');
      return;
    }
    const d = await r.json();
    const area = document.getElementById('trainChartsArea');
    area.style.display = 'grid';

    const epochs = d.train_loss.map((_, i) => i + 1);

    // Loss chart
    if (charts.loss) charts.loss.destroy();
    const lc = document.getElementById('lossChart').getContext('2d');
    charts.loss = new Chart(lc, {
      type: 'line',
      data: {
        labels: epochs,
        datasets: [
          { label: 'Train Loss', data: d.train_loss, borderColor: '#4f46e5', backgroundColor: '#4f46e520', tension: 0.3, pointRadius: 0, fill: true },
          { label: 'Val Loss',   data: d.val_loss,   borderColor: '#0ea5e9', backgroundColor: '#0ea5e920', tension: 0.3, pointRadius: 0, fill: true }
        ]
      },
      options: {
        ...chartDefaults(),
        plugins: { legend: { display: true, position: 'top' } }
      }
    });

    // MAE chart
    if (charts.mae) charts.mae.destroy();
    const mc = document.getElementById('maeChart').getContext('2d');
    charts.mae = new Chart(mc, {
      type: 'line',
      data: {
        labels: epochs,
        datasets: [{
          label: 'Val MAE (INR)', data: d.val_mae,
          borderColor: '#10b981', backgroundColor: '#10b98120',
          tension: 0.3, pointRadius: 0, fill: true
        }]
      },
      options: {
        ...chartDefaults(),
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: 'rgba(51,65,85,0.5)' } },
          y: { grid: { color: 'rgba(51,65,85,0.5)' }, ticks: { callback: v => '\u20B9' + Number(v).toLocaleString('en-IN') } }
        }
      }
    });

  } catch (e) {
    showTrainingStatus('Error loading history: ' + e.message, 'error');
  }
}

// ─── Retrain ───────────────────────────────────────────────────────────────
async function retrain() {
  if (!confirm('Retrain the model from scratch? This may take a minute.')) return;
  const btn = document.getElementById('retrainBtn');
  btn.disabled = true;
  btn.textContent = '⟳ Training...';
  showTrainingStatus('⟳ Training in progress... please wait (60-120 seconds)', 'info');
  try {
    const r = await fetch('/train', { method: 'POST' });
    const d = await r.json();
    if (d.error) {
      showTrainingStatus('Training failed: ' + d.error, 'error');
    } else {
      showTrainingStatus('✅ Model trained successfully! ' +
        (d.history ? `Final MAE: $${Number(d.history.val_mae.at(-1)).toLocaleString()}` : ''), 'success');
      checkHealth();
      loadHistory();
    }
  } catch (e) {
    showTrainingStatus('Error: ' + e.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '🔁 Retrain Model';
  }
}

function showTrainingStatus(msg, type) {
  const el = document.getElementById('trainingStatus');
  el.style.display = 'block';
  el.className = 'training-status ' + type;
  el.textContent = msg;
}

// ─── Smooth nav highlight ──────────────────────────────────────────────────
const sections = document.querySelectorAll('section[id]');
const navLinks  = document.querySelectorAll('.nav-link');
window.addEventListener('scroll', () => {
  let cur = '';
  sections.forEach(s => { if (window.scrollY >= s.offsetTop - 100) cur = s.id; });
  navLinks.forEach(l => {
    l.classList.toggle('active', l.getAttribute('href') === '#' + cur);
  });
});

// ─── Init ─────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  checkHealth();
  setInterval(checkHealth, 15000);
});
